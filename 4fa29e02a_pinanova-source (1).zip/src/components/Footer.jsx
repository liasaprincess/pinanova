import React from "react";
import { Link } from "react-router-dom";

const shopLinks = [
  { label: "All Artifacts", to: "/artifacts" },
  { label: "About Us", to: "/about" },
  { label: "Contact", to: "/contact" },
];

const policyLinks = [
  { label: "Terms & Conditions", to: "/terms" },
  { label: "Store Policies", to: "/policies" },
];

export default function Footer() {
  return (
    <footer className="bg-[#733540] text-[#E0D5EF]">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="celestial-rule mb-10" />
        <div className="grid md:grid-cols-3 gap-10 md:gap-6">
          <div>
            <p className="text-lg tracking-[0.3em] uppercase mb-4">pinanova</p>
            <p className="text-sm text-[#E0D5EF]/60 max-w-xs leading-relaxed">
              A curated collection of unique novelty items and gifts — each
              piece an artifact of wonder, made for the curious soul.
            </p>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-[0.25em] text-[#AA5D60] mb-4">
              Visit
            </h4>
            <ul className="space-y-2">
              {shopLinks.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-[#E0D5EF]/70 hover:text-[#E0D5EF] transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-[0.25em] text-[#AA5D60] mb-4">
              Legal
            </h4>
            <ul className="space-y-2">
              {policyLinks.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-[#E0D5EF]/70 hover:text-[#E0D5EF] transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 pt-6 border-t border-[#E0D5EF]/10 flex flex-col md:flex-row justify-between gap-4">
          <p className="text-xs text-[#E0D5EF]/50 tracking-wider">
            © {new Date().getFullYear()} Pinanova. All rights reserved.
          </p>
          <p className="text-xs text-[#E0D5EF]/50 tracking-wider">
            Forged in the dark, delivered with light.
          </p>
        </div>
      </div>
    </footer>
  );
}