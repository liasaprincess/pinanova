import React from "react";
import { useCart } from "@/lib/CartContext";
import { Link } from "react-router-dom";
import { X, Minus, Plus, Trash2 } from "lucide-react";
import { Image } from "@/components/ui/image";

export default function CartDrawer() {
  const { items, isOpen, setIsOpen, removeItem, updateQty, subtotal, clear } = useCart();

  if (!isOpen) return null;

  const shipping = subtotal === 0 || subtotal >= 150 ? 0 : 12;

  return (
    <div className="fixed inset-0 z-[60]">
      <div
        className="absolute inset-0 bg-black/60 backdrop-blur-sm"
        onClick={() => setIsOpen(false)}
      />
      <aside className="absolute right-0 top-0 h-full w-full max-w-md flex flex-col
        bg-[#032633]/70 backdrop-blur-2xl
        border-l border-[#E0D5EF]/25
        shadow-[0_0_40px_rgba(170,93,96,0.25),inset_0_1px_0_rgba(224,213,239,0.15),inset_0_-30px_60px_-40px_rgba(115,53,64,0.8)]">
        <div className="flex items-center justify-between px-6 py-5 border-b border-[#E0D5EF]/10">
          <h2 className="font-heading-italic text-2xl">Your Collection</h2>
          <button
            onClick={() => setIsOpen(false)}
            className="text-[#E0D5EF]/70 hover:text-[#E0D5EF] p-1"
            aria-label="Close cart"
          >
            <X size={20} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center px-6 text-center gap-4">
            <p className="font-heading-italic text-2xl text-[#E0D5EF]/80">
              Your collection awaits…
            </p>
            <Link
              to="/artifacts"
              onClick={() => setIsOpen(false)}
              className="border border-[#AA5D60] text-[#AA5D60] px-8 py-3 uppercase tracking-[0.2em] text-sm hover:bg-[#AA5D60] hover:text-[#032633] transition-colors"
            >
              Browse Artifacts
            </Link>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
              {items.map((item) => (
                <div key={item.id} className="flex gap-4">
                  <div className="h-20 w-20 shrink-0 overflow-hidden bg-[#733540]">
                    {item.image && (
                      <Image
                        src={item.image}
                        alt={item.name}
                        className="h-full w-full object-cover"
                      />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between gap-2">
                      <p className="text-sm font-medium text-[#E0D5EF] truncate">
                        {item.name}
                      </p>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="text-[#E0D5EF]/40 hover:text-[#AA5D60] transition-colors"
                        aria-label={`Remove ${item.name}`}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                    <p className="text-sm text-[#AA5D60] mt-1">
                      ${(item.price * item.qty).toFixed(2)}
                    </p>
                    <div className="flex items-center gap-3 mt-2">
                      <button
                        onClick={() => updateQty(item.id, item.qty - 1)}
                        className="h-7 w-7 border border-[#E0D5EF]/20 flex items-center justify-center hover:border-[#AA5D60] transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus size={13} />
                      </button>
                      <span className="text-sm w-4 text-center">{item.qty}</span>
                      <button
                        onClick={() => updateQty(item.id, item.qty + 1)}
                        className="h-7 w-7 border border-[#E0D5EF]/20 flex items-center justify-center hover:border-[#AA5D60] transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="px-6 py-5 border-t border-[#E0D5EF]/10 space-y-4">
              <div className="flex justify-between text-sm text-[#E0D5EF]/70">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm text-[#E0D5EF]/70">
                <span>Shipping</span>
                <span>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-base font-medium text-[#E0D5EF] pt-2 border-t border-[#E0D5EF]/10">
                <span>Total</span>
                <span>${(subtotal + shipping).toFixed(2)}</span>
              </div>
              <Link
                to="/checkout"
                onClick={() => setIsOpen(false)}
                className="block w-full bg-[#AA5D60] text-[#032633] text-center py-3 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors"
              >
                Proceed to Checkout
              </Link>
              <button
                onClick={clear}
                className="w-full text-center text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/40 hover:text-[#AA5D60] transition-colors"
              >
                Clear Collection
              </button>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}