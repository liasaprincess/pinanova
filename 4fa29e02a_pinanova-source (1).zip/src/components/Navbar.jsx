import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useCart } from "@/lib/CartContext";

const navLinks = [
  { label: "Artifacts", to: "/artifacts" },
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { count, setIsOpen } = useCart();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#032633]/80 backdrop-blur-md border-b border-[#E0D5EF]/10">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <Link to="/" className="text-lg tracking-[0.3em] uppercase text-[#E0D5EF]">
          pinanova
        </Link>

        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="text-sm uppercase tracking-[0.2em] text-[#E0D5EF]/70 hover:text-[#AA5D60] transition-colors"
            >
              {l.label}
            </Link>
          ))}
          <button
            onClick={() => setIsOpen(true)}
            className="relative text-sm uppercase tracking-[0.2em] text-[#E0D5EF]/70 hover:text-[#AA5D60] transition-colors"
          >
            Cart
            {count > 0 && (
              <span className="absolute -top-1 -right-3 text-[10px] h-4 w-4 rounded-full bg-[#AA5D60] text-[#032633] flex items-center justify-center font-semibold">
                {count}
              </span>
            )}
          </button>
        </div>

        {/* Mobile: dropdown menu trigger */}
        <div className="md:hidden relative">
          <button
            onClick={() => setOpen((o) => !o)}
            className="flex items-center gap-2 text-[#E0D5EF] p-1"
            aria-label="Open menu"
            aria-expanded={open}
          >
            <span className="flex flex-col gap-1">
              <span
                className={`block h-px w-5 bg-[#E0D5EF] transition-transform duration-300 ${
                  open ? "translate-y-[5px] rotate-45" : ""
                }`}
              />
              <span
                className={`block h-px w-5 bg-[#E0D5EF] transition-opacity duration-300 ${
                  open ? "opacity-0" : "opacity-100"
                }`}
              />
              <span
                className={`block h-px w-5 bg-[#E0D5EF] transition-transform duration-300 ${
                  open ? "-translate-y-[5px] -rotate-45" : ""
                }`}
              />
            </span>
          </button>

          {open && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setOpen(false)}
              />
              <nav
                className="absolute right-0 top-12 z-50 min-w-[200px]
                  bg-[#032633]/70 backdrop-blur-2xl
                  border border-[#E0D5EF]/25
                  shadow-[0_0_40px_rgba(170,93,96,0.25),inset_0_1px_0_rgba(224,213,239,0.15)]
                  py-3"
              >
                {navLinks.map((l) => (
                  <Link
                    key={l.to}
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block px-6 py-3 text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/75 hover:bg-[#AA5D60]/15 hover:text-[#AA5D60] transition-colors"
                  >
                    {l.label}
                  </Link>
                ))}
                <button
                  onClick={() => {
                    setOpen(false);
                    setIsOpen(true);
                  }}
                  className="w-full text-left px-6 py-3 text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/75 hover:bg-[#AA5D60]/15 hover:text-[#AA5D60] transition-colors flex items-center gap-2"
                >
                  Cart
                  {count > 0 && (
                    <span className="text-[10px] h-4 px-1 rounded-full bg-[#AA5D60] text-[#032633] flex items-center justify-center font-semibold">
                      {count}
                    </span>
                  )}
                </button>
              </nav>
            </>
          )}
        </div>
      </div>
    </header>
  );
}