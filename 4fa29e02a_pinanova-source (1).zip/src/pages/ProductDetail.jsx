import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { useCart } from "@/lib/CartContext";

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [notFound, setNotFound] = useState(false);
  const { addItem } = useCart();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const p = await base44.entities.Product.get(id);
        if (!cancelled) setProduct(p);
      } catch (e) {
        if (!cancelled) setNotFound(true);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [id]);

  if (notFound) {
    return (
      <div className="pt-16 min-h-[70vh] flex flex-col items-center justify-center text-center px-6">
        <h1 className="font-heading-italic text-4xl text-[#E0D5EF]">Artifact not found</h1>
        <Link
          to="/artifacts"
          className="mt-6 border border-[#AA5D60] text-[#AA5D60] px-8 py-3 uppercase tracking-[0.2em] text-sm hover:bg-[#AA5D60] hover:text-[#032633] transition-colors"
        >
          Return to the collection
        </Link>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="pt-16 min-h-[70vh] flex items-center justify-center">
        <div className="h-8 w-8 border-2 border-[#733540] border-t-[#AA5D60] rounded-full animate-spin" />
      </div>
    );
  }

  const gallery = product.gallery?.length ? product.gallery : [product.image].filter(Boolean);

  return (
    <div className="pt-16">
      <div className="max-w-7xl mx-auto px-6 py-10">
        <Link
          to="/artifacts"
          className="text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/50 hover:text-[#AA5D60] transition-colors"
        >
          ← Back to collection
        </Link>

        {/* 60/40 split */}
        <div className="mt-8 grid lg:grid-cols-[3fr_2fr] gap-12">
          {/* Gallery */}
          <div className="space-y-6">
            {gallery.map((src, i) => (
              <div key={i} className="overflow-hidden bg-[#733540]/30">
                <Image
                  src={src}
                  alt={`${product.name} ${i + 1}`}
                  className="w-full object-cover"
                />
              </div>
            ))}
          </div>

          {/* Sticky info panel */}
          <div className="lg:sticky lg:top-24 h-fit">
            <p className="text-xs uppercase tracking-[0.3em] text-[#AA5D60] mb-3">
              {product.category}
            </p>
            <h1 className="font-heading-italic text-4xl md:text-5xl text-[#E0D5EF] leading-tight">
              {product.name}
            </h1>
            <p className="mt-4 text-2xl text-[#E0D5EF]">${product.price.toFixed(2)}</p>

            <div className="celestial-rule my-8" />

            <p className="text-[#E0D5EF]/75 leading-relaxed">
              {product.description || product.story}
            </p>

            <button
              onClick={() => addItem({ id: product.id, name: product.name, price: product.price, image: product.image })}
              disabled={!product.in_stock}
              className="mt-8 w-full bg-[#AA5D60] text-[#032633] py-4 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              {product.in_stock ? "Add to Collection" : "Currently Unavailable"}
            </button>

            <div className="mt-6 space-y-2 text-sm text-[#E0D5EF]/50">
              <p>· Free shipping over $150</p>
              <p>· Handmade & ethically sourced</p>
              <p>· Packaged in midnight cloth</p>
            </div>
          </div>
        </div>
      </div>

      {/* Story of the object */}
      {product.story && (
        <section className="mt-16 bg-[#733540]/60 py-20 px-6">
          <div className="max-w-3xl mx-auto">
            <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-4 text-center">
              The Story of the Object
            </p>
            <p className="font-heading-italic text-2xl md:text-3xl text-[#E0D5EF] text-center leading-relaxed">
              {product.story}
            </p>
          </div>
        </section>
      )}
    </div>
  );
}