import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { Upload } from "lucide-react";

export default function Admin() {
  const [tab, setTab] = useState("products");
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({ name: "", price: "", category: "objects", description: "", image: "" });

  async function refresh() {
    setLoading(true);
    try {
      const [p, o, i] = await Promise.all([
        base44.entities.Product.list({ sort: "-created_date", limit: 100 }),
        base44.entities.Order.list({ sort: "-created_date", limit: 100 }),
        base44.entities.Inquiry.list({ sort: "-created_date", limit: 100 }),
      ]);
      setProducts(p.items || []);
      setOrders(o.items || []);
      setInquiries(i.items || []);
    } catch (e) {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
  }, []);

  const resetForm = () =>
    setForm({ name: "", price: "", category: "objects", description: "", image: "" });

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadPublicFile({ file });
      setForm((f) => ({ ...f, image: file_url }));
    } catch (err) {
      alert("Upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const data = {
      name: form.name,
      price: Number(form.price) || 0,
      category: form.category,
      description: form.description,
      image: form.image,
    };
    if (editing) {
      await base44.entities.Product.update(editing, data);
    } else {
      await base44.entities.Product.create(data);
    }
    setEditing(null);
    resetForm();
    await refresh();
  };

  const tabs = [
    { id: "products", label: "Products" },
    { id: "orders", label: "Orders" },
    { id: "inquiries", label: "Inquiries" },
  ];

  const inputClass =
    "w-full bg-[#032633] border border-[#E0D5EF]/25 px-3 py-2 text-[#E0D5EF] text-sm focus:border-[#AA5D60] focus:outline-none";

  return (
    <div className="pt-16 min-h-[80vh]">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between flex-wrap gap-4 mb-8">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-2">
              Private chamber
            </p>
            <h1 className="font-heading-italic text-4xl text-[#E0D5EF]">
              Store Management
            </h1>
          </div>
          <Link
            to="/"
            className="text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/50 hover:text-[#AA5D60] transition-colors"
          >
            ← View storefront
          </Link>
        </div>

        <div className="flex gap-2 mb-8 border-b border-[#E0D5EF]/10">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-5 py-3 text-xs uppercase tracking-[0.2em] border-b-2 transition-colors ${
                tab === t.id
                  ? "border-[#AA5D60] text-[#AA5D60]"
                  : "border-transparent text-[#E0D5EF]/50 hover:text-[#E0D5EF]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="space-y-10">
          {/* PRODUCTS */}
          {tab === "products" && (
            <>
              <div className="grid lg:grid-cols-2 gap-10">
                <div>
                  <h2 className="font-heading-italic text-2xl text-[#E0D5EF] mb-4">
                    {editing ? "Edit artifact" : "Add an artifact"}
                  </h2>
                  <form onSubmit={handleSave} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <input
                        className={inputClass}
                        placeholder="Name"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        required
                      />
                      <input
                        className={inputClass}
                        placeholder="Price"
                        type="number"
                        step="0.01"
                        value={form.price}
                        onChange={(e) => setForm({ ...form, price: e.target.value })}
                        required
                      />
                    </div>
                    <select
                      className={inputClass}
                      value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value })}
                    >
                      {["objects", "candles", "crystals", "apothecary", "textiles", "stationery"].map((c) => (
                        <option key={c} value={c}>
                          {c.charAt(0).toUpperCase() + c.slice(1)}
                        </option>
                      ))}
                    </select>
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <label
                          className={`flex items-center gap-2 cursor-pointer border border-[#E0D5EF]/25 px-4 py-2 text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/70 hover:border-[#AA5D60] hover:text-[#AA5D60] transition-colors ${
                            uploading ? "opacity-50 pointer-events-none" : ""
                          }`}
                        >
                          <Upload className="h-4 w-4" />
                          {uploading ? "Uploading…" : "Upload photo"}
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={handleImageUpload}
                            disabled={uploading}
                          />
                        </label>
                        {form.image && (
                          <div className="h-12 w-12 overflow-hidden border border-[#E0D5EF]/20">
                            <Image src={form.image} alt="preview" className="h-full w-full object-cover" />
                          </div>
                        )}
                      </div>
                      <input
                        className={inputClass}
                        placeholder="…or paste an image URL"
                        value={form.image}
                        onChange={(e) => setForm({ ...form, image: e.target.value })}
                      />
                    </div>
                    <textarea
                      className={inputClass}
                      placeholder="Description"
                      rows={3}
                      value={form.description}
                      onChange={(e) => setForm({ ...form, description: e.target.value })}
                    />
                    <div className="flex gap-3">
                      <button
                        type="submit"
                        className="bg-[#AA5D60] text-[#032633] px-6 py-2.5 uppercase tracking-[0.2em] text-xs font-semibold hover:bg-[#AA5D60]/90"
                      >
                        {editing ? "Save changes" : "Add artifact"}
                      </button>
                      {editing && (
                        <button
                          type="button"
                          onClick={() => { setEditing(null); resetForm(); }}
                          className="border border-[#E0D5EF]/30 text-[#E0D5EF]/60 px-6 py-2.5 uppercase tracking-[0.2em] text-xs hover:text-[#E0D5EF]"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </form>
                </div>

                <div>
                  <h2 className="font-heading-italic text-2xl text-[#E0D5EF] mb-4">
                    Current collection
                  </h2>
                  {loading ? (
                    <p className="text-[#E0D5EF]/50 py-10 text-center">Loading…</p>
                  ) : (
                    <div className="space-y-2">
                      {products.map((p) => (
                        <div
                          key={p.id}
                          className="flex items-center gap-3 border border-[#E0D5EF]/10 px-3 py-2"
                        >
                          <div className="h-10 w-10 shrink-0 overflow-hidden bg-[#733540]">
                            {p.image && (
                              <Image src={p.image} alt={p.name} className="h-full w-full object-cover" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-[#E0D5EF] truncate">{p.name}</p>
                            <p className="text-xs text-[#AA5D60]">${Number(p.price).toFixed(2)}</p>
                          </div>
                          <button
                            onClick={async () => {
                              setForm({
                                name: p.name,
                                price: String(p.price),
                                category: p.category || "objects",
                                description: p.description || "",
                                image: p.image || "",
                              });
                              setEditing(p.id);
                            }}
                            className="text-xs uppercase tracking-wide text-[#E0D5EF]/60 hover:text-[#AA5D60]"
                          >
                            Edit
                          </button>
                          <button
                            onClick={async () => {
                              await base44.entities.Product.delete(p.id);
                              await refresh();
                            }}
                            className="text-xs uppercase tracking-wide text-[#E0D5EF]/40 hover:text-[#AA5D60]"
                          >
                            Delete
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* ORDERS */}
          {tab === "orders" && (
            <div>
              <h2 className="font-heading-italic text-2xl text-[#E0D5EF] mb-4">
                Incoming orders
              </h2>
              {loading ? (
                <p className="text-[#E0D5EF]/50 py-10 text-center">Loading…</p>
              ) : orders.length === 0 ? (
                <p className="text-[#E0D5EF]/50 py-10 text-center">No orders yet.</p>
              ) : (
                <div className="space-y-4">
                  {orders.map((o) => (
                    <div key={o.id} className="border border-[#E0D5EF]/10 p-5">
                      <div className="flex flex-wrap justify-between gap-3">
                        <div>
                          <p className="text-[#E0D5EF] font-medium">{o.customer_name}</p>
                          <p className="text-sm text-[#E0D5EF]/50">{o.customer_email}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[#AA5D60] font-medium">
                            ${Number(o.total).toFixed(2)}
                          </p>
                          <span className="text-[10px] uppercase tracking-wide px-2 py-0.5 bg-[#733540] text-[#E0D5EF]">
                            {o.status}
                          </span>
                        </div>
                      </div>
                      {o.items?.length > 0 && (
                        <div className="mt-3 space-y-1 border-t border-[#E0D5EF]/10 pt-3">
                          {o.items.map((it, idx) => (
                            <p key={idx} className="text-sm text-[#E0D5EF]/70">
                              {it.name} × {it.qty} — ${(Number(it.price) * it.qty).toFixed(2)}
                            </p>
                          ))}
                        </div>
                      )}
                      {o.shipping_address && (
                        <p className="mt-3 text-xs text-[#E0D5EF]/40">
                          {o.shipping_address}
                          {o.city ? `, ${o.city}` : ""}
                          {o.postal_code ? ` ${o.postal_code}` : ""}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* INQUIRIES */}
          {tab === "inquiries" && (
            <div>
              <h2 className="font-heading-italic text-2xl text-[#E0D5EF] mb-4">
                Customer inquiries
              </h2>
              {loading ? (
                <p className="text-[#E0D5EF]/50 py-10 text-center">Loading…</p>
              ) : inquiries.length === 0 ? (
                <p className="text-[#E0D5EF]/50 py-10 text-center">No inquiries yet.</p>
              ) : (
                <div className="space-y-4">
                  {inquiries.map((q) => (
                    <div key={q.id} className="border border-[#E0D5EF]/10 p-5">
                      <div className="flex justify-between items-start gap-4">
                        <div>
                          <p className="text-[#E0D5EF] font-medium">{q.name}</p>
                          <p className="text-sm text-[#E0D5EF]/50">{q.email}</p>
                        </div>
                        <span className="text-[10px] uppercase tracking-wide px-2 py-0.5 bg-[#733540] text-[#E0D5EF]">
                          {q.status}
                        </span>
                      </div>
                      {q.message && (
                        <p className="mt-3 text-[#E0D5EF]/75">{q.message}</p>
                      )}
                      {q.status === "new" && (
                        <button
                          onClick={async () => {
                            await base44.entities.Inquiry.update(q.id, { status: "read" });
                            await refresh();
                          }}
                          className="mt-3 text-xs uppercase tracking-wide text-[#AA5D60] hover:text-[#E0D5EF]"
                        >
                          Mark as read
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}