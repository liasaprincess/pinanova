import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { useCart } from "@/lib/CartContext";

function ProductCard({ product }) {
  const { addItem } = useCart();
  return (
    <div className="group relative">
      <Link to={`/product/${product.id}`} className="block overflow-hidden">
        <div className="relative aspect-[4/5] overflow-hidden">
          {product.image && (
            <Image
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          )}
        </div>
      </Link>
      <div className="pt-4 flex justify-between items-baseline gap-2">
        <div className="min-w-0">
          <Link
            to={`/product/${product.id}`}
            className="block text-[11px] uppercase tracking-[0.2em] text-[#E0D5EF] truncate"
          >
            {product.name}
          </Link>
          <Link
            to={`/product/${product.id}`}
            className="block text-xs uppercase tracking-[0.2em] text-[#AA5D60] mt-1"
          >
            ${product.price.toFixed(2)}
          </Link>
        </div>
        <button
          onClick={() => addItem({ id: product.id, name: product.name, price: product.price, image: product.image })}
          className="text-[10px] uppercase tracking-[0.2em] text-[#E0D5EF]/50 hover:text-[#AA5D60] whitespace-nowrap transition-colors"
        >
          Add
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  const [featured, setFeatured] = useState([]);
  const [heroProduct, setHeroProduct] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const { items } = await base44.entities.Product.filter(
          {},
          { sort: "-featured", limit: 8 }
        );
        const shown = items.filter((p) => p.featured).slice(0, 3);
        setFeatured(items.length ? items.slice(0, 4) : []);
        setHeroProduct(items.find((p) => p.featured) || items[0] || null);
        void shown;
      } catch (e) {
        /* ignore */
      }
    }
    load();
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-[78vh] flex items-center overflow-hidden">
        <div className="relative max-w-7xl mx-auto px-6 w-full py-24 pt-32">
          <div className="max-w-xl">
            <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-5">
              Unique novelty · Gifts
            </p>
            <h1 className="font-heading-italic text-5xl md:text-7xl text-[#E0D5EF] leading-[1.05]">
              Curated artifacts for the curious soul
            </h1>
            <p className="mt-6 text-lg text-[#E0D5EF]/70 max-w-md leading-relaxed">
              Every piece in our collection carries a story — a candle poured
              under the moon, a stone carved with intention. Find yours.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/artifacts"
                className="bg-[#AA5D60] text-[#032633] px-9 py-4 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors"
              >
                Explore the Collection
              </Link>
              <Link
                to="/about"
                className="border border-[#E0D5EF]/40 text-[#E0D5EF] px-9 py-4 uppercase tracking-[0.2em] text-sm hover:border-[#AA5D60] hover:text-[#AA5D60] transition-colors"
              >
                Our Story
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured collection */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-3">
              The Collection
            </p>
            <h2 className="font-heading-italic text-4xl md:text-5xl text-[#E0D5EF]">
              Selected artifacts
            </h2>
          </div>
          <Link
            to="/artifacts"
            className="hidden md:block text-xs uppercase tracking-[0.2em] text-[#E0D5EF]/60 hover:text-[#AA5D60] transition-colors"
          >
            View all →
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-12">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>

        <div className="mt-12 md:hidden">
          <Link
            to="/artifacts"
            className="block text-center border border-[#AA5D60] text-[#AA5D60] py-3 uppercase tracking-[0.2em] text-sm"
          >
            View all artifacts
          </Link>
        </div>
      </section>

      {/* Brand quote band */}
      <section className="py-20 px-6 border-y border-[#E0D5EF]/10">
        <div className="max-w-3xl mx-auto text-center">
          <p className="font-heading-italic text-3xl md:text-4xl text-[#E0D5EF] leading-snug">
            "Every object in our night-blooming garden is chosen to kindle a
            little magic in an ordinary day."
          </p>
          <p className="mt-6 text-xs uppercase tracking-[0.3em] text-[#AA5D60]">
            — The Pinanova House
          </p>
        </div>
      </section>

      {/* Categories teaser */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="font-heading-italic text-4xl text-[#E0D5EF] mb-10 text-center">
          Realms to wander
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Apothecary", img: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&q=80", to: "/artifacts" },
            { label: "Crystals", img: "https://images.unsplash.com/photo-1563262127-1734e7e28da6?w=800&q=80", to: "/artifacts" },
            { label: "Candles", img: "https://images.unsplash.com/photo-1603006905003-be475563bc59?w=800&q=80", to: "/artifacts" },
            { label: "Objects", img: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=800&q=80", to: "/artifacts" },
          ].map((c) => (
            <Link key={c.label} to={c.to} className="group relative overflow-hidden aspect-square">
              <Image
                src={c.img}
                alt={c.label}
                className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#032633]/80 via-transparent to-transparent" />
              <span className="absolute bottom-4 left-4 text-[11px] uppercase tracking-[0.25em] text-[#E0D5EF]">
                {c.label}
              </span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}