import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useCart } from "@/lib/CartContext";
import { Image } from "@/components/ui/image";

export default function Checkout() {
  const { items, subtotal, clear, setIsOpen } = useCart();
  const [form, setForm] = useState({
    name: "",
    email: "",
    address: "",
    city: "",
    postal_code: "",
    country: "",
  });
  const [status, setStatus] = useState("review"); // review | placing | done
  const [error, setError] = useState("");
  const [orderId, setOrderId] = useState(null);

  const shipping = subtotal === 0 || subtotal >= 150 ? 0 : 12;
  const total = subtotal + shipping;

  const steps = ["Review", "Details", "Confirmation"];
  const currentStep =
    status === "done" ? 2 : status === "placing" ? 0 : items.length ? 0 : 0;

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.address) {
      setError("Please fill in your name, email and shipping address.");
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setStatus("placing");
    try {
      const order = await base44.entities.Order.create({
        customer_name: form.name,
        customer_email: form.email,
        shipping_address: form.address,
        city: form.city,
        postal_code: form.postal_code,
        country: form.country,
        items: items.map((i) => ({
          id: i.id,
          name: i.name,
          price: i.price,
          qty: i.qty,
        })),
        subtotal,
        shipping,
        total,
        status: "pending",
      });
      setOrderId(order.id);
      clear();
      setIsOpen(false);
      setStatus("done");
    } catch (err) {
      setError("Something went wrong placing your order. Please try again.");
      setStatus("review");
    }
  };

  const inputClass =
    "w-full bg-[#032633] border border-[#E0D5EF]/25 px-4 py-3 text-[#E0D5EF] text-sm placeholder:text-[#E0D5EF]/40 focus:border-[#AA5D60] focus:outline-none transition-colors";

  return (
    <div className="pt-16 max-w-3xl mx-auto px-6 py-14">
      {/* Manifesting progress bar */}
      <div className="w-full h-[3px] bg-[#733540] rounded-full mb-3">
        <div
          className="h-full bg-[#AA5D60] rounded-full transition-all duration-700"
          style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
        />
      </div>
      <p className="text-xs uppercase tracking-[0.25em] text-[#AA5D60] mb-8">
        {steps[currentStep]} — manifest order
      </p>

      {status === "done" ? (
        <div className="text-center py-16">
          <p className="font-heading-italic text-4xl md:text-5xl text-[#E0D5EF]">
            Your order is manifested
          </p>
          <p className="mt-5 text-[#E0D5EF]/70 max-w-md mx-auto leading-relaxed">
            Thank you, {form.name.split(" ")[0]} — your collection is being
            wrapped in midnight cloth. A confirmation will follow your email,
            {form.email ? ` ${form.email}` : ""}.
          </p>
          {orderId && (
            <p className="mt-4 text-xs uppercase tracking-[0.2em] text-[#AA5D60]">
              Reference: {orderId.slice(0, 8).toUpperCase()}
            </p>
          )}
          <Link
            to="/artifacts"
            className="inline-block mt-8 border border-[#AA5D60] text-[#AA5D60] px-8 py-3 uppercase tracking-[0.2em] text-sm hover:bg-[#AA5D60] hover:text-[#032633] transition-colors"
          >
            Continue exploring
          </Link>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16">
          <p className="font-heading-italic text-3xl text-[#E0D5EF]">
            Your collection is empty
          </p>
          <Link
            to="/artifacts"
            className="inline-block mt-6 border border-[#AA5D60] text-[#AA5D60] px-8 py-3 uppercase tracking-[0.2em] text-sm hover:bg-[#AA5D60] hover:text-[#032633] transition-colors"
          >
            Browse artifacts
          </Link>
        </div>
      ) : (
        <>
          {/* Order summary */}
          <div className="border border-[#E0D5EF]/10 mb-10">
            <div className="px-6 py-4 border-b border-[#E0D5EF]/10">
              <h2 className="font-heading-italic text-2xl text-[#E0D5EF]">
                Your Collection
              </h2>
            </div>
            <div className="px-6 py-4 space-y-4">
              {items.map((i) => (
                <div key={i.id} className="flex items-center gap-4">
                  <div className="h-16 w-16 shrink-0 overflow-hidden bg-[#733540]">
                    {i.image && (
                      <Image src={i.image} alt={i.name} className="h-full w-full object-cover" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-[#E0D5EF] truncate">{i.name}</p>
                    <p className="text-xs text-[#E0D5EF]/50">Qty {i.qty}</p>
                  </div>
                  <span className="text-sm text-[#E0D5EF]">
                    ${(i.price * i.qty).toFixed(2)}
                  </span>
                </div>
              ))}
            </div>
            <div className="px-6 py-4 border-t border-[#E0D5EF]/10 space-y-2 text-sm">
              <div className="flex justify-between text-[#E0D5EF]/70">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#E0D5EF]/70">
                <span>Shipping</span>
                <span>{shipping === 0 ? "Free" : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="flex justify-between text-lg font-medium text-[#E0D5EF] pt-2">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Details form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <h2 className="font-heading-italic text-2xl text-[#E0D5EF]">
              Manifest the delivery
            </h2>

            <div className="grid md:grid-cols-2 gap-5">
              <input
                className={inputClass}
                name="name"
                placeholder="Full name *"
                value={form.name}
                onChange={handleChange}
                required
              />
              <input
                className={inputClass}
                name="email"
                type="email"
                placeholder="Email *"
                value={form.email}
                onChange={handleChange}
                required
              />
            </div>
            <input
              className={inputClass}
              name="address"
              placeholder="Street address *"
              value={form.address}
              onChange={handleChange}
              required
            />
            <div className="grid md:grid-cols-3 gap-5">
              <input
                className={inputClass}
                name="city"
                placeholder="City"
                value={form.city}
                onChange={handleChange}
              />
              <input
                className={inputClass}
                name="postal_code"
                placeholder="Postal code"
                value={form.postal_code}
                onChange={handleChange}
              />
              <input
                className={inputClass}
                name="country"
                placeholder="Country"
                value={form.country}
                onChange={handleChange}
              />
            </div>

            {error && (
              <p className="text-sm text-[#AA5D60] border border-[#AA5D60]/40 bg-[#AA5D60]/10 px-4 py-3">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={status === "placing"}
              className="w-full bg-[#AA5D60] text-[#032633] py-4 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors disabled:opacity-60"
            >
              {status === "placing" ? "Manifesting…" : "Place Order"}
            </button>
            <p className="text-xs text-[#E0D5EF]/40 text-center">
              Orders are processed securely. No payment is taken at this stage.
            </p>
          </form>
        </>
      )}
    </div>
  );
}