import React from "react";

const sections = [
  {
    title: "1. Acceptance of Terms",
    body: "By accessing or using the Pinanova website and placing an order, you agree to be bound by these Terms & Conditions and our Store Policies. If you do not agree with any part of these terms, please do not use our services.",
  },
  {
    title: "2. The Collection",
    body: "All products are available while supplies last. While we strive to display accurate imagery and descriptions, colors may vary slightly due to the handmade nature of many of our pieces. We reserve the right to discontinue any product at any time.",
  },
  {
    title: "3. Pricing & Payment",
    body: "All prices are listed in the currency shown at checkout. We reserve the right to change prices at any time without prior notice. Prices shown on the product page at the time of order are the prices you pay. Payment is processed securely at checkout.",
  },
  {
    title: "4. Orders & Acceptance",
    body: "Placing an order constitutes an offer to purchase. We reserve the right to accept or decline any order for any reason, including limitations on availability, errors in pricing, or suspected fraudulent activity. We will not charge you until an order is accepted.",
  },
  {
    title: "5. Shipping & Delivery",
    body: "Orders are typically prepared and dispatched within 2-5 business days. Delivery times vary by destination. Risk of loss passes to you upon delivery. Please review our Store Policies for full shipping details.",
  },
  {
    title: "6. Returns & Refunds",
    body: "Because many of our items are handmade or personalized, returns are handled on a case-by-case basis. If you are not completely satisfied, please contact us within 14 days of receiving your order. See our Store Policies for details.",
  },
  {
    title: "7. Intellectual Property",
    body: "All content on this site — including text, photography, logos, and original designs — is the property of Pinanova or its licensors and is protected by applicable intellectual property laws. You may not reproduce, distribute, or use our content without written permission.",
  },
  {
    title: "8. Limitation of Liability",
    body: "To the fullest extent permitted by law, Pinanova shall not be liable for any indirect, incidental, or consequential damages arising from the use of our site or products. Our total liability shall not exceed the amount paid for the relevant order.",
  },
  {
    title: "9. Governing Law",
    body: "These terms are governed by the laws of the jurisdiction in which Pinanova operates, without regard to conflict-of-law principles. Any disputes shall be resolved in the competent courts of that jurisdiction.",
  },
  {
    title: "10. Changes to These Terms",
    body: "We may update these Terms & Conditions from time to time. Changes take effect when posted on this page. Continued use of our services after changes constitutes acceptance of the updated terms.",
  },
];

export default function Terms() {
  return (
    <div className="pt-16">
      <section className="max-w-4xl mx-auto px-6 py-16">
        <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-4">
          Legal
        </p>
        <h1 className="font-heading-italic text-5xl md:text-6xl text-[#E0D5EF]">
          Terms &amp; Conditions
        </h1>
        <p className="mt-5 text-[#E0D5EF]/60">
          Last updated: {new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
        </p>
        <div className="celestial-rule my-10" />
        <div className="space-y-10">
          {sections.map((s) => (
            <div key={s.title}>
              <h2 className="font-heading-italic text-2xl text-[#AA5D60] mb-3">
                {s.title}
              </h2>
              <p className="text-[#E0D5EF]/75 leading-relaxed">{s.body}</p>
            </div>
          ))}
        </div>
        <div className="celestial-rule my-10" />
        <p className="text-sm text-[#E0D5EF]/50">
          Questions about these terms? Visit our{" "}
          <span className="text-[#AA5D60]">Contact</span> page to reach us.
        </p>
      </section>
    </div>
  );
}