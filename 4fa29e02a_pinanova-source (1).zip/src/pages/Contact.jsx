import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle2 } from "lucide-react";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState("idle"); // idle | sending | done
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email) {
      setError("Please provide your name and email.");
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) {
      setError("Please enter a valid email address.");
      return;
    }
    setError("");
    setStatus("sending");
    try {
      await base44.entities.Inquiry.create({
        name: form.name,
        email: form.email,
        message: form.message,
        status: "new",
      });
      setForm({ name: "", email: "", message: "" });
      setStatus("done");
    } catch (err) {
      setError("Something went wrong sending your message. Please try again.");
      setStatus("idle");
    }
  };

  const inputClass =
    "w-full bg-[#032633] border border-[#E0D5EF]/25 px-4 py-3 text-[#E0D5EF] text-base placeholder:text-[#E0D5EF]/40 focus:border-[#AA5D60] focus:outline-none transition-colors";

  return (
    <div className="pt-16">
      <section className="max-w-6xl mx-auto px-6 py-16">
        <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-4">
          Reach us
        </p>
        <h1 className="font-heading-italic text-5xl md:text-6xl text-[#E0D5EF]">
          Contact the house
        </h1>
        <p className="mt-5 text-lg text-[#E0D5EF]/60 max-w-lg leading-relaxed">
          Questions about an artifact, an order, or a custom request? Write to
          us — we answer every message with care.
        </p>

        <div className="mt-14 grid lg:grid-cols-2 gap-14">
          {/* Form */}
          <div>
            {status === "done" ? (
              <div className="border border-[#AA5D60]/40 bg-[#AA5D60]/10 p-8 text-center">
                <CheckCircle2 className="mx-auto mb-4 text-[#AA5D60]" size={40} />
                <p className="font-heading-italic text-2xl text-[#E0D5EF]">
                  Your message has been sent
                </p>
                <p className="mt-3 text-[#E0D5EF]/70">
                  The house will reply to you at {form.email || "your email"}{" "}
                  shortly.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid md:grid-cols-2 gap-5">
                  <input
                    className={inputClass}
                    name="name"
                    placeholder="Your name *"
                    value={form.name}
                    onChange={handleChange}
                    required
                  />
                  <input
                    className={inputClass}
                    name="email"
                    type="email"
                    placeholder="Your email *"
                    value={form.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <textarea
                  className={inputClass}
                  name="message"
                  placeholder="Your message"
                  rows={6}
                  value={form.message}
                  onChange={handleChange}
                />
                {error && (
                  <p className="text-sm text-[#AA5D60] border border-[#AA5D60]/40 bg-[#AA5D60]/10 px-4 py-3">
                    {error}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="w-full md:w-auto bg-[#AA5D60] text-[#032633] px-10 py-4 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors disabled:opacity-60"
                >
                  {status === "sending" ? "Sending…" : "Send Message"}
                </button>
              </form>
            )}
          </div>

          {/* Details */}
          <div className="space-y-8">
            <div>
              <h3 className="text-xs uppercase tracking-[0.3em] text-[#AA5D60] mb-3">
                Correspond
              </h3>
              <p className="text-[#E0D5EF]/75 leading-relaxed">
                For questions about orders, shipping or returns, include your
                order reference so we can help you faster.
              </p>
            </div>
            <div>
              <h3 className="text-xs uppercase tracking-[0.3em] text-[#AA5D60] mb-3">
                Custom requests
              </h3>
              <p className="text-[#E0D5EF]/75 leading-relaxed">
                Looking for something particular — a one-of-a-kind gift, a
                custom bundle, or a piece you saw long ago? Tell us the story
                and we'll see what we can find.
              </p>
            </div>
            <div>
              <h3 className="text-xs uppercase tracking-[0.3em] text-[#AA5D60] mb-3">
                Hours
              </h3>
              <p className="text-[#E0D5EF]/75 leading-relaxed">
                We reply to messages within 2 business days, Monday through
                Friday.
              </p>
            </div>
            <div className="celestial-rule" />
            <p className="text-sm text-[#E0D5EF]/50">
              Please review our{" "}
              <span className="text-[#AA5D60]">Terms &amp; Conditions</span> and{" "}
              <span className="text-[#AA5D60]">Store Policies</span> before
              placing an order.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}