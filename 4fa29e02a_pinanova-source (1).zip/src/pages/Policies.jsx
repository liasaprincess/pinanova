import React, { useState } from "react";

const policies = [
  {
    id: "shipping",
    label: "Shipping",
    body: "Orders are prepared and dispatched within 2-5 business days, Monday through Friday. Free standard shipping is available on orders over $150. Delivery times vary by destination — please allow 5-10 business days for domestic and 10-20 for international. You will receive a confirmation once your order has been dispatched. We are not responsible for delays caused by carriers or customs.",
  },
  {
    id: "returns",
    label: "Returns & Exchanges",
    body: "Because many of our pieces are handmade or one-of-a-kind, returns are handled on a case-by-case basis. If you are not completely satisfied, please contact us within 14 days of receiving your order with your reference number and the reason. Items must be returned in their original condition. Standard items may be eligible for a refund or exchange; personalized and final-sale items cannot be returned unless damaged on arrival.",
  },
  {
    id: "damages",
    label: "Damaged on Arrival",
    body: "If your order arrives damaged, please contact us within 5 days of delivery with a photo of the item and its packaging. We will arrange a replacement or refund at no cost to you. Our packaging is designed to protect fragile pieces, but accidents can still happen in transit.",
  },
  {
    id: "privacy",
    label: "Privacy",
    body: "We collect only the information needed to process your order and communicate with you — your name, email, shipping address, and order details. We do not sell or share your personal information with third parties for their marketing. By submitting your details, you agree to our use of them to fulfil your order and respond to your enquiries.",
  },
  {
    id: "payment",
    label: "Payment & Security",
    body: "Payments are processed securely. We do not store your card details on our servers. All transactions are handled by trusted payment processors. If you have concerns about the security of a transaction, please contact us before completing your purchase.",
  },
  {
    id: "personalisation",
    label: "Personalised & Final-Sale Items",
    body: "Personalised, engraved, and custom-made pieces are made to your specifications and cannot be returned or exchanged unless they arrive damaged or with an error on our part. Please review your personalisation carefully before completing your order.",
  },
  {
    id: "ethics",
    label: "Ethical Sourcing",
    body: "We are committed to sourcing our pieces ethically and sustainably. Our products are handmade by artisans or ethically sourced from trusted suppliers. If you would like to know more about the origin of a particular piece, please reach out via our Contact page.",
  },
];

export default function Policies() {
  const [open, setOpen] = useState(policies[0].id);

  return (
    <div className="pt-16">
      <section className="max-w-4xl mx-auto px-6 py-16">
        <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-4">
          The fine print
        </p>
        <h1 className="font-heading-italic text-5xl md:text-6xl text-[#E0D5EF]">
          Store Policies
        </h1>
        <p className="mt-5 text-[#E0D5EF]/60 max-w-lg leading-relaxed">
          Everything you need to know about shipping, returns, privacy and more
          from the House of Pinanova.
        </p>
        <div className="celestial-rule my-10" />

        <div className="space-y-4">
          {policies.map((p) => {
            const isOpen = open === p.id;
            return (
              <div
                key={p.id}
                className="border border-[#E0D5EF]/10 overflow-hidden"
              >
                <button
                  onClick={() => setOpen(isOpen ? "" : p.id)}
                  className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-[#E0D5EF]/[0.03] transition-colors"
                >
                  <span className="font-heading-italic text-2xl text-[#E0D5EF]">
                    {p.label}
                  </span>
                  <span className="text-[#AA5D60] text-xl transition-transform duration-300" style={{ transform: isOpen ? "rotate(45deg)" : "none" }}>
                    +
                  </span>
                </button>
                {isOpen && (
                  <div className="px-6 pb-6">
                    <p className="text-[#E0D5EF]/75 leading-relaxed">{p.body}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="celestial-rule my-10" />
        <p className="text-sm text-[#E0D5EF]/50">
          Questions about any policy? Reach us via our Contact page — we're
          happy to help.
        </p>
      </section>
    </div>
  );
}