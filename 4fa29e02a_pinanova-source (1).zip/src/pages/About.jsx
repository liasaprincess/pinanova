import React from "react";
import { Link } from "react-router-dom";
import { Image } from "@/components/ui/image";

export default function About() {
  return (
    <div className="pt-16">
      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=1800&q=80')",
          }}
        />
        <div className="absolute inset-0 bg-[#032633]/70" />
        <div className="relative max-w-4xl mx-auto px-6 text-center py-20">
          <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-5">
            The House of Pinanova
          </p>
          <h1 className="font-heading-italic text-5xl md:text-6xl text-[#E0D5EF] leading-tight">
            We gather small wonders for everyday souls
          </h1>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-4xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="overflow-hidden">
            <Image
              src="https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?w=900&q=80"
              alt="Night-blooming botanical still life"
              className="w-full object-cover"
            />
          </div>
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-[#AA5D60] mb-4">
              Our origin
            </p>
            <h2 className="font-heading-italic text-3xl text-[#E0D5EF] mb-5">
              Born between the candle and the moon
            </h2>
            <div className="space-y-4 text-[#E0D5EF]/70 leading-relaxed">
              <p>
                Pinanova began as a small night market stall, gathered around a
                single candle, trading curiosities that made people slow down
                and look twice.
              </p>
              <p>
                Today we curate a collection of unique novelty items and gifts —
                apothecary jars, hand-poured candles, carved stones, velvet
                cloths — each chosen for the quiet story it carries and the
                small magic it adds to an ordinary day.
              </p>
              <p>
                Everything we sell is handmade or ethically sourced, packaged
                with care, and sent into the world with a wish.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 px-6 bg-[#733540]/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="font-heading-italic text-4xl text-[#E0D5EF] text-center mb-12">
            What we hold dear
          </h2>
          <div className="grid md:grid-cols-3 gap-10 text-center">
            {[
              { t: "Curiosity", d: "We believe a good gift should make someone pause, wonder, and smile — and we hunt for pieces that do." },
              { t: "Craft", d: "Every artifact is handmade or ethically sourced from artisans who take as much care as we do." },
              { t: "Kind Magic", d: "Each order is wrapped in midnight cloth and sent out with a genuine wish for the one receiving it." },
            ].map((v) => (
              <div key={v.t}>
                <h3 className="font-heading-italic text-2xl text-[#AA5D60] mb-3">
                  {v.t}
                </h3>
                <p className="text-[#E0D5EF]/70 leading-relaxed">{v.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-6 py-20 text-center">
        <h2 className="font-heading-italic text-4xl text-[#E0D5EF] mb-6">
          Find your next curiosity
        </h2>
        <Link
          to="/artifacts"
          className="inline-block bg-[#AA5D60] text-[#032633] px-10 py-4 uppercase tracking-[0.2em] text-sm font-semibold hover:bg-[#AA5D60]/90 transition-colors"
        >
          Explore the collection
        </Link>
      </section>
    </div>
  );
}