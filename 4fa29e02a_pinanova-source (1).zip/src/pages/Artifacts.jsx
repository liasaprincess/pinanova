import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Image } from "@/components/ui/image";
import { useCart } from "@/lib/CartContext";

const categories = [
  { label: "All Artifacts", value: "all" },
  { label: "Apothecary", value: "apothecary" },
  { label: "Crystals", value: "crystals" },
  { label: "Candles", value: "candles" },
  { label: "Textiles", value: "textiles" },
  { label: "Stationery", value: "stationery" },
  { label: "Objects", value: "objects" },
];

function ProductCard({ product }) {
  const { addItem } = useCart();
  return (
    <div className="group relative">
      <div className="relative overflow-hidden">
        <Link to={`/product/${product.id}`} className="block aspect-[4/5] overflow-hidden">
          {product.image && (
            <Image
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          )}
        </Link>
        <button
          onClick={() => addItem({ id: product.id, name: product.name, price: product.price, image: product.image })}
          className="absolute bottom-0 left-0 right-0 bg-[#032633]/85 backdrop-blur-sm py-3 text-[11px] uppercase tracking-[0.2em] text-[#E0D5EF] opacity-0 translate-y-4 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 hover:text-[#AA5D60]"
        >
          Add to Collection
        </button>
      </div>
      <div className="pt-4 flex justify-between items-baseline">
        <Link
          to={`/product/${product.id}`}
          className="block text-[11px] uppercase tracking-[0.2em] text-[#E0D5EF] truncate"
        >
          {product.name}
        </Link>
        <span className="text-xs text-[#AA5D60] whitespace-nowrap ml-3">
          ${product.price.toFixed(2)}
        </span>
      </div>
    </div>
  );
}

export default function Artifacts() {
  const [params] = useSearchParams();
  const active = params.get("category") || "all";
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const query = active === "all" ? {} : { category: active };
        const { items } = await base44.entities.Product.filter(query, {
          sort: "-featured",
          limit: 50,
        });
        if (!cancelled) setProducts(items);
      } catch (e) {
        if (!cancelled) setProducts([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [active]);

  const activeLabel = categories.find((c) => c.value === active)?.label || "All Artifacts";

  return (
    <div className="pt-16">
      <section className="max-w-7xl mx-auto px-6 py-14">
        <p className="text-xs uppercase tracking-[0.35em] text-[#AA5D60] mb-4">
          The Collection
        </p>
        <h1 className="font-heading-italic text-5xl md:text-6xl text-[#E0D5EF]">
          Curated artifacts
        </h1>
      </section>

      <section className="max-w-7xl mx-auto px-6 pb-24 flex gap-10">
        {/* Left side menu */}
        <aside className="hidden md:block w-56 shrink-0">
          <div className="sticky top-24">
            <p className="text-[11px] uppercase tracking-[0.3em] text-[#AA5D60] mb-5 pb-4 border-b border-[#E0D5EF]/15">
              Realms
            </p>
            <nav className="flex flex-col">
              {categories.map((c) => {
                const isActive = active === c.value;
                return (
                  <Link
                    key={c.value}
                    to={c.value === "all" ? "/artifacts" : `/artifacts?category=${c.value}`}
                    className={`relative py-3 text-xs uppercase tracking-[0.2em] transition-colors ${
                      isActive
                        ? "text-[#AA5D60]"
                        : "text-[#E0D5EF]/60 hover:text-[#E0D5EF]"
                    }`}
                  >
                    {isActive && (
                      <span className="absolute -left-4 top-1/2 -translate-y-1/2 h-px w-3 bg-[#AA5D60]" />
                    )}
                    {c.label}
                  </Link>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Main grid */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-8">
            <p className="text-sm text-[#E0D5EF]/60">
              {loading ? "Gathering…" : `${products.length} ${products.length === 1 ? "piece" : "pieces"} · ${activeLabel}`}
            </p>
          </div>

          {/* Mobile category filter */}
          <div className="md:hidden mb-8 flex flex-wrap gap-3">
            {categories.map((c) => (
              <Link
                key={c.value}
                to={c.value === "all" ? "/artifacts" : `/artifacts?category=${c.value}`}
                className={`px-4 py-2 text-[11px] uppercase tracking-[0.2em] border transition-colors ${
                  active === c.value
                    ? "border-[#AA5D60] text-[#AA5D60]"
                    : "border-[#E0D5EF]/20 text-[#E0D5EF]/60 hover:border-[#AA5D60]/50 hover:text-[#E0D5EF]"
                }`}
              >
                {c.label}
              </Link>
            ))}
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <div className="h-8 w-8 border-2 border-[#733540] border-t-[#AA5D60] rounded-full animate-spin" />
            </div>
          ) : products.length === 0 ? (
            <p className="text-center text-[#E0D5EF]/50 py-20">
              This realm is currently empty. Return soon.
            </p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-12">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}